const { MongoClient } = require("mongodb");
const conn_uri = process.env.URI;

exports.handler = async function (event, context) {
  const client = new MongoClient(conn_uri);
  await client.connect();

  const database = client.db("timak");
  const videos = database.collection("videos");
  const results = await videos.findAll();
  console.log(insertResult);

  // Ensures that the client will close when you finish/error
  await client.close();
  const response = {
    statusCode: 200,
    body: results,
  };
  return results;
};
