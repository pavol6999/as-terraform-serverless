const { MongoClient } = require("mongodb");
const conn_uri = process.env.URI


exports.handler = async function (event, context) {
   
    const client = new MongoClient(conn_uri);
    await client.connect();
  
    const database = client.db("timak");
    const videos = database.collection("videos");
    const insertResult = await videos.insertOne(event);
    console.log(insertResult);
  
    // Ensures that the client will close when you finish/error
    await client.close();
  
};
